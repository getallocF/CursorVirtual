#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_NDK_HOME:=${ANDROID_NDK_ROOT:-$HOME/android-ndk-aarch64}}"
TOOLCHAIN="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake"

if [[ ! -f "$TOOLCHAIN" ]]; then
  cat >&2 <<MSG
Android NDK toolchain not found:
  $TOOLCHAIN

This script does not use Termux's ordinary host clang as a substitute NDK.
Install an Android-ARM64-hosted NDK/toolchain first, then set ANDROID_NDK_HOME.
MSG
  exit 2
fi

cmake -S "$ROOT" -B "$ROOT/build-arm64-v8a" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-28 \
  -DANDROID_STL=c++_shared \
  -DCMAKE_BUILD_TYPE=Release \
  -DMOD_ID=PaperDollTouch \
  -DMOD_NAME="PaperDollTouch (Experimental Cursor Core)" \
  -DMOD_AUTHOR=PaperDollTouch \
  -DMOD_VERSION=0.2.0 \
  -DMOD_LIBRARY_NAME=PaperDollTouch \
  '-DMOD_MINECRAFT_VERSIONS=["1.26.60*"]'

cmake --build "$ROOT/build-arm64-v8a" --target levi_package --parallel "$(nproc)"

PACK="$ROOT/build-arm64-v8a/PaperDollTouch-0.2.0-arm64-v8a.levipack"
LIB="$ROOT/build-arm64-v8a/libPaperDollTouch.so"
if [[ ! -f "$PACK" || ! -f "$LIB" ]]; then
  echo "Build command completed but expected output is missing." >&2
  exit 3
fi

file "$LIB"
readelf -h "$LIB" | grep -E 'Class:|Machine:|Type:'
readelf -d "$LIB" | grep -E 'NEEDED|RUNPATH|RPATH' || true
sha256sum "$LIB" "$PACK"
printf '\nPackage: %s\nLibrary: %s\n' "$PACK" "$LIB"
