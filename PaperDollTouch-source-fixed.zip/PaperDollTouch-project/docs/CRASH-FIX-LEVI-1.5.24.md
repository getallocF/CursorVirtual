# Native crash fix — LeviLauncher 1.5.24

## Symptom

The tombstone shows `SIGSEGV`, fault address `0x10`, in `pl::modmenu::registerModule()` in `libpreloader.so`, called from `libPaperDollTouch.so`.

## Cause identified

The build was pinned to preloader-android tag `0.2.2`. That tag uses an older `pl::modmenu::ModuleInfo` C++ layout than the preloader bundled in LeviLauncher 1.5.24. The newer runtime contains an additional `onKeybind` callback field. Passing a `ModuleInfo`/builder built against the older headers across the C++ ABI boundary can crash during `registerModule()`.

## Fix applied

`CMakeLists.txt` now pins `preloader-android` to commit `7ca94daedfa30d6d4c265fc9b591768e8dc1f5af`, identified as the preloader revision bundled with LeviLauncher 1.5.24. The build workflow also uses Android NDK `28.2.13676358` to match the referenced working target.

## Verification status

This change addresses the ABI mismatch indicated by the tombstone, but it is not yet confirmed on the user's device. A successful GitHub Actions build only confirms compilation and packaging; after installing the artifact, verify that Minecraft starts without a native crash. If it still crashes, provide the new tombstone and Launch Log.

## Feature status

This compatibility fix does not implement the missing Argon features. Actual inventory slot detection/highlighting and paper-doll rotation still require verified Minecraft 1.26.60.4 integration points.
