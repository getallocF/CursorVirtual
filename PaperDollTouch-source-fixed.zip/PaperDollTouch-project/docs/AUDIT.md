# PaperDollTouch forensic audit — 2026-10-29

## Supplied input

Only one upload was available: `PaperDollTouch.levipack` (13,334 bytes). The two other ZIPs requested by the user were not attached in this turn.

Archive members:

- `PaperDollTouch/manifest.json` — 366 bytes
- `PaperDollTouch/config/config.json` — 712 bytes
- `PaperDollTouch/config/config.schema.json` — 712 bytes
- `PaperDollTouch/libPaperDollTouch.so` — 10,408 bytes

No `.cpp`, `.h`, `CMakeLists.txt`, Gradle, Android manifest, SDK, dependency lock, or build scripts are included. The `config.json` and `config.schema.json` entries are byte-identical, and the latter is not a JSON Schema document.

## Binary facts observed

- `ELF 64-bit LSB shared object, ARM aarch64`, Android API 24 note, NDK build metadata.
- Dynamic exported function: `PLGetModRegistration`.
- `.text` size: `0x18c` = 396 bytes.
- The function disassembly calls `dlsym(RTLD_DEFAULT, "__android_log_print")`; if found, it logs the text `[MobileCursor] Loaded PaperDollTouch v2.1.0 (Relative Trackpad + White Cursor + Green Slot Hover)` with tag `PaperDollTouch`, then returns `1`.
- Dynamic imports do not include the documented Preloader `registerTouchCallback`, `submitDrawCommands`, `registerImage`, or `pl::memory::hook` functions. The binary contains no calls to those APIs.
- Source-file names in DWARF/symbol metadata (`CursorEngine.cpp`, `GlOverlayRenderer.cpp`, `PaperDollHeadTracker.cpp`, `PaperDollTouchMod.cpp`, `SlotHoverDetector.cpp`) are not evidence of implementations. The symbol table contains no functions for those modules; the tiny `.text` and disassembly confirm that the entrypoint's active behavior is a log message.
- The binary RUNPATH points into `/data/data/com.termux/files/usr/lib`, which should be checked against the actual game's loader process and dependency resolution before reuse. This archive's library must not be treated as verified for runtime loading merely because it is a valid ARM64 ELF.

## Package/loader alignment

LeviLauncher Android docs specify a `preload-native` manifest whose `entry` names the library inside the mod folder, one registered long-lived native mod using `PL_REGISTER_MOD`, and package layout containing manifest, `.so`, and config files. The submitted archive follows much of the outer package shape but the active library does not implement the feature advertised by the manifest. Its additional `targetMinecraftVersion` field is not the documented `minecraft_versions` field.

## Available documented API vs required game behavior

Documented Preloader 0.2.2 public headers include:

- `<pl/Mod.hpp>` native mod lifecycle and `PL_REGISTER_MOD`;
- `<pl/Input.hpp>` touch/key/mouse callbacks;
- `<pl/ModMenu.hpp>` HUD draw commands and RGBA image registration;
- `<pl/Config.hpp>` typed JSON config;
- `<pl/memory/Hook.hpp>` generic hooks, which require a valid target pointer.

These do not by themselves identify inventory GUI lifecycle, inventory slot rectangles/hover states, or the paper-doll render model fields. No version-specific signature database, `libminecraftpe.so`, source SDK exposing those internals, or test device/log is included. No guessed symbol, address, offset, or signature was added.

## Tests actually run in this environment

- ZIP integrity and listing: passed.
- Manifest and configs read: passed.
- ELF identification/readelf and exported-symbol inspection: passed.
- ARM64 disassembly of `PLGetModRegistration`: passed; confirms log-only behavior.
- Android build: **not run**. No Android NDK/toolchain was installed; CMake dependencies could not be fetched because GitHub DNS was unavailable.
- Host unit tests: `cmake -S . -B build-host -G Ninja -DCMAKE_BUILD_TYPE=Debug`, `cmake --build build-host`, and `ctest --test-dir build-host --output-on-failure` passed: 1/1 test suite, 0 failures. These test only cursor math, not Minecraft integration.
- In-game input/render/UI tests: **not run**.

## Follow-up crash analysis (LeviLauncher 1.5.24)

A later tombstone shows the crash in `pl::modmenu::registerModule()` called from the built mod library. The source build was pinned to preloader-android tag `0.2.2`. This tag has an older `ModuleInfo` layout than the revision bundled with LeviLauncher 1.5.24: the runtime includes an additional `onKeybind` callback. The CMake pin is now updated to the exact runtime revision `7ca94daedfa30d6d4c265fc9b591768e8dc1f5af`. See `CRASH-FIX-LEVI-1.5.24.md`. This is a source-level ABI correction; it still needs an in-game retest.

## Honest completion state

This deliverable is a source recovery/engineering prototype, not a completed PaperDollTouch release. The relative cursor math and manual opt-in overlay input path are implemented against documented SDK API. Inventory-open/close detection, green hover of the actual slot, and paper-doll head/model rotation remain unimplemented pending verified 26.60 game integration. No Android binary or `.levipack` is included because it could not be safely built and checked here.
