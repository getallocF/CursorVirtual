# Build result for the attached-session environment

Date: 2026-10-29

## Passed

- Source host-mode CMake configuration completed.
- Host-mode build completed. It compiled only `src/core/CursorEngine.cpp` and `tests/test_cursor_engine.cpp`.
- CTest result: 1/1 tests passed, 0 failed.
- JSON syntax check passed for the config file, config schema, and manifest template after variable substitution.
- The uploaded `.levipack` was inspected as an archive and its shared object identified as ELF64 AArch64. Disassembly verified the original binary only logs a load message.

## Not run / unavailable

- Android native project compile/link/package: not run because no Android NDK toolchain was found in this execution environment.
- Dependency fetch for the Android build: previous attempt could not resolve GitHub DNS in this environment.
- LeviLauncher runtime load test and Minecraft 26.60 in-game test: not run.
- Inventory GUI detection, real slot hit testing/highlight, and paper-doll head/model rotation: not implemented because no verified 26.60 internal APIs/hooks were available in the supplied package or public SDK.

No new `.so` or `.levipack` is included. The original binary is not copied into the source deliverable.
