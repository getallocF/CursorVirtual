# Minecraft 1.26.60.4 compatibility metadata

The manifest must use the documented `minecraft_versions` array. LeviLauncher supports exact versions and prefix wildcards. The build targets `1.26.60*` so it matches patch versions such as `1.26.60.4`.

This metadata fixes the launcher's compatibility filter only. It does not certify game-internal hooks, inventory slot hit-testing, or paper-doll model rotation against Minecraft 1.26.60.4. Those require runtime validation and verified signatures/API access.
