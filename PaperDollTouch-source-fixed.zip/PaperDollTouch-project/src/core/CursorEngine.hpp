#pragma once

#include <algorithm>
#include <cmath>

namespace pdt {

struct Point {
    float x{0.0f};
    float y{0.0f};
};

struct Rect {
    float x{0.0f};
    float y{0.0f};
    float width{0.0f};
    float height{0.0f};

    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] bool contains(Point p) const noexcept;
};

struct CursorSettings {
    float screenWidth{0.0f};
    float screenHeight{0.0f};
    float sensitivity{1.0f};
    // 0 means no filtering; values near 1 add more smoothing.
    float smoothing{0.0f};
};

class CursorEngine final {
public:
    void reset(CursorSettings settings) noexcept;
    [[nodiscard]] bool beginDrag(Point finger, const Rect& trackpad) noexcept;
    [[nodiscard]] bool move(Point finger) noexcept;
    void endDrag() noexcept;

    [[nodiscard]] bool isDragging() const noexcept { return mDragging; }
    [[nodiscard]] bool hasPosition() const noexcept { return mHasPosition; }
    [[nodiscard]] Point position() const noexcept { return mCursor; }

private:
    CursorSettings mSettings{};
    Point mCursor{};
    Point mLastFinger{};
    Point mFilteredDelta{};
    bool mDragging{false};
    bool mHasPosition{false};
};

} // namespace pdt
