#include "core/CursorEngine.hpp"

namespace pdt {

bool Rect::valid() const noexcept {
    return std::isfinite(x) && std::isfinite(y) &&
           std::isfinite(width) && std::isfinite(height) &&
           width > 0.0f && height > 0.0f;
}

bool Rect::contains(Point p) const noexcept {
    return valid() && std::isfinite(p.x) && std::isfinite(p.y) &&
           p.x >= x && p.y >= y && p.x < x + width && p.y < y + height;
}

void CursorEngine::reset(CursorSettings settings) noexcept {
    if (!std::isfinite(settings.screenWidth) || settings.screenWidth <= 0.0f) {
        settings.screenWidth = 0.0f;
    }
    if (!std::isfinite(settings.screenHeight) || settings.screenHeight <= 0.0f) {
        settings.screenHeight = 0.0f;
    }
    if (!std::isfinite(settings.sensitivity)) settings.sensitivity = 1.0f;
    settings.sensitivity = std::clamp(settings.sensitivity, 0.05f, 5.0f);
    if (!std::isfinite(settings.smoothing)) settings.smoothing = 0.0f;
    settings.smoothing = std::clamp(settings.smoothing, 0.0f, 0.95f);

    mSettings = settings;
    mCursor = {settings.screenWidth * 0.5f, settings.screenHeight * 0.5f};
    mLastFinger = {};
    mFilteredDelta = {};
    mDragging = false;
    mHasPosition = settings.screenWidth > 0.0f && settings.screenHeight > 0.0f;
}

bool CursorEngine::beginDrag(Point finger, const Rect& trackpad) noexcept {
    if (!mHasPosition || !trackpad.contains(finger)) return false;
    mDragging = true;
    mLastFinger = finger;
    mFilteredDelta = {};
    return true;
}

bool CursorEngine::move(Point finger) noexcept {
    if (!mDragging || !mHasPosition || !std::isfinite(finger.x) || !std::isfinite(finger.y)) {
        return false;
    }

    const Point rawDelta{finger.x - mLastFinger.x, finger.y - mLastFinger.y};
    mLastFinger = finger;

    const float newWeight = 1.0f - mSettings.smoothing;
    mFilteredDelta.x = mFilteredDelta.x * mSettings.smoothing + rawDelta.x * newWeight;
    mFilteredDelta.y = mFilteredDelta.y * mSettings.smoothing + rawDelta.y * newWeight;

    mCursor.x = std::clamp(mCursor.x + mFilteredDelta.x * mSettings.sensitivity,
                           0.0f, mSettings.screenWidth - 1.0f);
    mCursor.y = std::clamp(mCursor.y + mFilteredDelta.y * mSettings.sensitivity,
                           0.0f, mSettings.screenHeight - 1.0f);
    return true;
}

void CursorEngine::endDrag() noexcept {
    mDragging = false;
    mLastFinger = {};
    mFilteredDelta = {};
}

} // namespace pdt
