#pragma once

#include "core/CursorEngine.hpp"
#include "mod/Config.h"

#include <atomic>
#include <memory>
#include <mutex>

#include <pl/Mod.hpp>

namespace pdt {

class PaperDollTouchMod final {
public:
    static PaperDollTouchMod& instance();
    PaperDollTouchMod();
    ~PaperDollTouchMod();

    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }
    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    bool handleTouch(int action, int pointerId, Point point);
    void setArmed(bool enabled);
    void submitCursor(Point position, bool visible);
    [[nodiscard]] bool geometryConfigured() const noexcept;

    ll::mod::NativeMod& mSelf;
    std::unique_ptr<class ConfigHolder> mConfig;
    CursorEngine mCursor;
    mutable std::mutex mStateMutex;
    std::atomic_bool mRunning{false};
    std::atomic_bool mArmed{false};
    bool mTouchCallbackRegistered{false};
    bool mMenuModuleRegistered{false};
    bool mImageRegistered{false};
    bool mCursorVisible{false};
    int mActivePointerId{-1};
};

} // namespace pdt
