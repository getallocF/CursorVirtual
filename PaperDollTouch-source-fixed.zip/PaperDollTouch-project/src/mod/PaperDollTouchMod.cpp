#include "mod/PaperDollTouchMod.h"

#include <array>
#include <cmath>
#include <cstddef>
#include <filesystem>
#include <span>
#include <string>
#include <system_error>

#include <pl/Config.hpp>
#include <pl/Input.hpp>
#include <pl/ModMenu.hpp>

namespace pdt {
namespace {
constexpr char kModuleId[] = "paperdolltouch.experimental_cursor";
constexpr char kCursorImageId[] = "paperdolltouch.cursor.white";

// Android MotionEvent action constants forwarded by the public Preloader input bridge.
constexpr int kActionDown = 0;
constexpr int kActionUp = 1;
constexpr int kActionMove = 2;
constexpr int kActionCancel = 3;
constexpr float kCursorWidth = 16.0f;
constexpr float kCursorHeight = 24.0f;

using CursorPixels = std::array<unsigned char, 16U * 24U * 4U>;

const CursorPixels& cursorImage() {
    // A small pointer-like arrow bitmap with a black outer edge and white fill.
    static const CursorPixels pixels = [] {
        constexpr std::array<const char*, 24> rows{
            "X...............", "XX..............", "X.X.............", "X..X............",
            "X...X...........", "X....X..........", "X.....X.........", "X......X........",
            "X.......X.......", "X........X......", "X.....XXXXX.....", "X...XX.XXXX.....",
            "X..X...XXXXX....", "X.X.....XXXXX...", "XX.......XXXX...", "X..........XXX..",
            "...........XXX..", "............XX..", "............XX..", "............X...",
            "............X...", "............X...", "................", "................"};
        CursorPixels out{};
        std::array<bool, 16U * 24U> shape{};
        for (std::size_t y = 0; y < rows.size(); ++y) {
            for (std::size_t x = 0; x < 16U; ++x) {
                shape[y * 16U + x] = rows[y][x] == 'X';
            }
        }
        for (std::size_t y = 0; y < 24U; ++y) {
            for (std::size_t x = 0; x < 16U; ++x) {
                bool border = false;
                for (int oy = -1; oy <= 1; ++oy) {
                    for (int ox = -1; ox <= 1; ++ox) {
                        const int nx = static_cast<int>(x) + ox;
                        const int ny = static_cast<int>(y) + oy;
                        if (nx >= 0 && nx < 16 && ny >= 0 && ny < 24 &&
                            shape[static_cast<std::size_t>(ny) * 16U + static_cast<std::size_t>(nx)]) {
                            border = true;
                        }
                    }
                }
                const bool isShape = shape[y * 16U + x];
                const std::size_t i = (y * 16U + x) * 4U;
                if (isShape) {
                    out[i + 0U] = 255; out[i + 1U] = 255; out[i + 2U] = 255; out[i + 3U] = 255;
                } else if (border) {
                    out[i + 0U] = 0; out[i + 1U] = 0; out[i + 2U] = 0; out[i + 3U] = 255;
                }
            }
        }
        return out;
    }();
    return pixels;
}

} // namespace

class ConfigHolder final {
public:
    pl::config::ConfigFile<ModConfig> file;
    ModConfig value{};
};

PaperDollTouchMod& PaperDollTouchMod::instance() {
    static PaperDollTouchMod mod;
    return mod;
}

PaperDollTouchMod::PaperDollTouchMod() : mSelf(*ll::mod::NativeMod::current()) {}

PaperDollTouchMod::~PaperDollTouchMod() = default;

bool PaperDollTouchMod::load() {
    auto& self = getSelf();
    std::error_code ec;
    std::filesystem::create_directories(self.getConfigDir(), ec);
    if (ec) {
        self.getLogger().error("Cannot create config directory: {}", ec.message());
        return false;
    }

    mConfig = std::make_unique<ConfigHolder>();
    if (!mConfig->file.load()) {
        self.getLogger().error("Failed to read/write config/config.json or schema");
        mConfig.reset();
        return false;
    }
    mConfig->value = mConfig->file.value();
    if (!std::isfinite(mConfig->value.sensitivity)) mConfig->value.sensitivity = 1.35f;
    if (!std::isfinite(mConfig->value.smoothing)) mConfig->value.smoothing = 0.45f;
    self.getLogger().info(
        "Loaded PaperDollTouch experimental cursor core. Inventory, slot, and paper-doll hooks are not enabled.");
    return true;
}

bool PaperDollTouchMod::enable() {
    auto& self = getSelf();
    if (!mConfig || !mConfig->value.enabled) {
        self.getLogger().info("PaperDollTouch disabled by config");
        return true;
    }

    if (!mImageRegistered) {
        const auto& pixels = cursorImage();
        mImageRegistered = pl::modmenu::registerImage(
            kCursorImageId, std::span<const unsigned char>(pixels.data(), pixels.size()), 16, 24);
        if (!mImageRegistered) {
            self.getLogger().error("Could not register cursor image; cursor preview remains unavailable");
        }
    }

    if (!mMenuModuleRegistered) {
        mMenuModuleRegistered = pl::modmenu::ModuleBuilder(
            kModuleId, "PaperDollTouch — experimental cursor core")
            .modId(self.getId())
            .description("Manual relative-trackpad prototype only. Not connected to inventory detection, slot hover, or paper-doll rotation.")
            .defaultEnabled(false)
            .hideInHudEditor(true)
            .onToggle([this](std::string_view, bool value) { setArmed(value); })
            .registerModule();
        if (!mMenuModuleRegistered) {
            self.getLogger().error("Failed to register the experimental cursor module in Mod Menu");
            return false;
        }
    }

    mRunning.store(true, std::memory_order_release);
    if (!mTouchCallbackRegistered) {
        pl::input::registerTouchCallback([this](const pl::input::TouchEvent& event) {
            return handleTouch(event.action, event.pointerId, Point{event.x, event.y});
        });
        mTouchCallbackRegistered = true;
    }

    if (!geometryConfigured()) {
        self.getLogger().warn(
            "Cursor mode is safe/off by default. Set screenWidthUnits, screenHeightUnits, trackpadX/Y/Width/Height in config.json before enabling the module.");
    }
    self.getLogger().info("PaperDollTouch experimental cursor module registered (manual mode, default off)");
    return true;
}

bool PaperDollTouchMod::disable() {
    mRunning.store(false, std::memory_order_release);
    mArmed.store(false, std::memory_order_release);
    {
        std::lock_guard lock(mStateMutex);
        mCursor.endDrag();
        mCursorVisible = false;
        mActivePointerId = -1;
    }
    submitCursor({}, false);
    if (mMenuModuleRegistered) {
        pl::modmenu::unregisterModule(kModuleId);
        mMenuModuleRegistered = false;
    }
    return true;
}

bool PaperDollTouchMod::unload() {
    (void)disable();
    mConfig.reset();
    return true;
}

bool PaperDollTouchMod::geometryConfigured() const noexcept {
    if (!mConfig) return false;
    const auto& c = mConfig->value;
    const bool finite = std::isfinite(c.screenWidthUnits) && std::isfinite(c.screenHeightUnits) &&
                        std::isfinite(c.trackpadX) && std::isfinite(c.trackpadY) &&
                        std::isfinite(c.trackpadWidth) && std::isfinite(c.trackpadHeight);
    return finite && c.screenWidthUnits > 1.0f && c.screenHeightUnits > 1.0f &&
           c.trackpadWidth > 1.0f && c.trackpadHeight > 1.0f &&
           c.trackpadX >= 0.0f && c.trackpadY >= 0.0f &&
           c.trackpadX + c.trackpadWidth <= c.screenWidthUnits &&
           c.trackpadY + c.trackpadHeight <= c.screenHeightUnits;
}

void PaperDollTouchMod::setArmed(bool enabled) {
    const bool canArm = enabled && mRunning.load(std::memory_order_acquire) &&
                        geometryConfigured() && mImageRegistered;
    mArmed.store(canArm, std::memory_order_release);
    if (!canArm) {
        {
            std::lock_guard lock(mStateMutex);
            mCursor.endDrag();
            mCursorVisible = false;
            mActivePointerId = -1;
        }
        submitCursor({}, false);
        if (enabled) {
            getSelf().getLogger().warn("Cursor module could not arm: check image registration and coordinate config");
        }
        return;
    }

    const auto& c = mConfig->value;
    {
        std::lock_guard lock(mStateMutex);
        mCursor.reset(CursorSettings{c.screenWidthUnits, c.screenHeightUnits,
                                     c.sensitivity, c.smoothing});
        mCursorVisible = false;
        mActivePointerId = -1;
    }
    submitCursor({}, false);
}

bool PaperDollTouchMod::handleTouch(int action, int pointerId, Point point) {
    if (!mRunning.load(std::memory_order_acquire) || !mArmed.load(std::memory_order_acquire) ||
        !mConfig || !geometryConfigured()) {
        return false;
    }

    const auto& c = mConfig->value;
    const Rect pad{c.trackpadX, c.trackpadY, c.trackpadWidth, c.trackpadHeight};
    bool consumed = false;
    bool showCursor = false;
    Point position{};

    {
        std::lock_guard lock(mStateMutex);
        if (action == kActionDown) {
            if (!mCursor.beginDrag(point, pad)) return false;
            mActivePointerId = pointerId;
            mCursorVisible = true;
            consumed = true;
            showCursor = true;
            position = mCursor.position();
        } else if (mCursor.isDragging() && pointerId == mActivePointerId && action == kActionMove) {
            consumed = mCursor.move(point);
            showCursor = mCursorVisible;
            position = mCursor.position();
        } else if (mCursor.isDragging() && pointerId == mActivePointerId &&
                   (action == kActionUp || action == kActionCancel)) {
            mCursor.endDrag();
            mActivePointerId = -1;
            consumed = true;
            showCursor = mCursorVisible;
            position = mCursor.position();
        }
    }

    if (showCursor) submitCursor(position, true);
    return consumed;
}

void PaperDollTouchMod::submitCursor(Point position, bool visible) {
    if (!mMenuModuleRegistered) return;
    if (visible && mImageRegistered) {
        const pl::modmenu::DrawCommand command{
            .type = pl::modmenu::DrawCommandType::Image,
            .x = position.x,
            .y = position.y,
            .w = kCursorWidth,
            .h = kCursorHeight,
            .imageId = kCursorImageId,
        };
        const std::array<pl::modmenu::DrawCommand, 1> commands{command};
        pl::modmenu::submitDrawCommands(kModuleId, commands);
    } else {
        const std::array<pl::modmenu::DrawCommand, 0> commands{};
        pl::modmenu::submitDrawCommands(kModuleId, commands);
    }
}

} // namespace pdt
