#pragma once

namespace pdt {

struct ModConfig {
    int version = 1;
    bool enabled = true;
    // These must be calibrated to the coordinate units used by both the
    // input callback and the loader's HUD overlay on the target device.
    float screenWidthUnits = 0.0f;
    float screenHeightUnits = 0.0f;
    float trackpadX = 0.0f;
    float trackpadY = 0.0f;
    float trackpadWidth = 0.0f;
    float trackpadHeight = 0.0f;
    float sensitivity = 1.35f;
    float smoothing = 0.45f;
};

} // namespace pdt
