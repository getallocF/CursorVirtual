#include "mod/PaperDollTouchMod.h"

#include <pl/Mod.hpp>

PL_REGISTER_MOD(pdt::PaperDollTouchMod, pdt::PaperDollTouchMod::instance())
