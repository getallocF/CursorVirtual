#include "core/CursorEngine.hpp"

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string_view>

namespace {
int failures = 0;
void check(bool condition, std::string_view message) {
    if (!condition) {
        ++failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}
bool near(float a, float b, float epsilon = 0.001f) {
    return std::fabs(a - b) <= epsilon;
}
}

int main() {
    using namespace pdt;
    const Rect pad{20.0f, 30.0f, 100.0f, 80.0f};
    check(pad.valid(), "positive rectangle should be valid");
    check(pad.contains({20.0f, 30.0f}), "rectangle includes its top-left edge");
    check(!pad.contains({120.0f, 50.0f}), "rectangle excludes right edge");
    check(!Rect{0, 0, 0, 10}.valid(), "zero-width trackpad must be invalid");

    CursorEngine cursor;
    cursor.reset({500.0f, 300.0f, 1.5f, 0.0f});
    check(cursor.hasPosition(), "positive canvas creates cursor position");
    check(near(cursor.position().x, 250.0f) && near(cursor.position().y, 150.0f),
          "cursor starts at screen center");
    check(!cursor.beginDrag({10.0f, 10.0f}, pad), "touch outside trackpad must not capture");
    check(cursor.beginDrag({25.0f, 35.0f}, pad), "touch inside trackpad captures drag");
    check(cursor.move({35.0f, 45.0f}), "active drag consumes relative movement");
    check(near(cursor.position().x, 265.0f) && near(cursor.position().y, 165.0f),
          "relative movement follows touch delta and sensitivity");
    cursor.endDrag();
    check(!cursor.isDragging(), "endDrag clears active input state");
    check(!cursor.move({45.0f, 55.0f}), "movement after endDrag is ignored");

    cursor.reset({100.0f, 100.0f, 2.0f, 0.0f});
    check(cursor.beginDrag({5.0f, 5.0f}, {0, 0, 20, 20}), "second drag begins");
    check(cursor.move({500.0f, -500.0f}), "large movement is handled");
    check(near(cursor.position().x, 99.0f) && near(cursor.position().y, 0.0f),
          "cursor is clamped to canvas boundaries");

    cursor.reset({100.0f, 100.0f, 1.0f, 0.5f});
    check(cursor.beginDrag({5.0f, 5.0f}, {0, 0, 20, 20}), "smoothed drag begins");
    check(cursor.move({15.0f, 5.0f}), "smoothed drag moves");
    check(near(cursor.position().x, 55.0f), "smoothing filters initial delta");

    cursor.reset({0.0f, 100.0f, 1.0f, 0.0f});
    check(!cursor.hasPosition(), "invalid canvas disables pointer movement");
    check(!cursor.beginDrag({1, 1}, {0, 0, 10, 10}), "invalid canvas cannot start drag");

    if (failures != 0) {
        std::cerr << failures << " test(s) failed\n";
        return EXIT_FAILURE;
    }
    std::cout << "All CursorEngine tests passed. (Core math only; no Minecraft runtime tested.)\n";
    return EXIT_SUCCESS;
}
